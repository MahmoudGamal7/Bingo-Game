package bingo.shared;

public class BingoException extends Exception {
    public BingoException() {
	super();
    }
    public BingoException(String s) {
	super(s);
    }
}
