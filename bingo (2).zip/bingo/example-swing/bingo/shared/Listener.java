package bingo.shared;

public interface Listener {
}
