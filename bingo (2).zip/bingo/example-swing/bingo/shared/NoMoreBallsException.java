package bingo.shared;

public class NoMoreBallsException extends BingoException {
}
