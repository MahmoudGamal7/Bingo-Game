package com.bingo;

import android.app.Application;

public class BingoApplication extends Application{
	
	public static final int WIN = 0;
	public static final int FAIL = 1;
	public static final int TIE = 2;
	
	public static int result;

}
